<html>
    <head>
    <link rel="stylesheet" href="../css/green.css">
    </head>
    <body>
        <h2>Administrator's Page</h2>
    <button type="button" onclick="reports()">Show Users</button>
    <div id="demo">
    </div>

    <script src="../js/admin.js"></script>
    </body>
</html>